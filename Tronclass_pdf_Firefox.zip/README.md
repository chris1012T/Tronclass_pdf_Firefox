[Chrome version of this extension](https://github.com/chris1012T/Tronclass_pdf)

# Tronclass PDF (Firefox)

This extension allows you to download most files from Tronclass in PDF format.

## Link to Firefox Browser ADD-ONS
[Firefox Browser ADD-ONS - Tronclass PDF](https://addons.mozilla.org/en-US/firefox/addon/tronclass-pdf-%E5%8E%9Ficlass-get-pdf/)

## Instructions
Open the materials on Tronclass, then click the icon in the extension tray directly.

Alternatively, you can right-click anywhere on the page and select "下載此教材 (Tronclass)" in the context menu.

## Contributing
Your pull requests are welcomed and greatly appreciated!